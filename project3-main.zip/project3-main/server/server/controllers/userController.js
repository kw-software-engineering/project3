const db = require('../models/userModel.js'); // pool 연결된 db
const { findUser } = require('../models/userModel');

// 로그인
const login = async (req, res) => {
    const { userId, userPwd } = req.body;
    const user = await findUser(userId, userPwd);

    if (user) {
        // role에 따라 name 조회
        let nameQuery = '';
        if (user.role === 'student') {
            nameQuery = 'SELECT name FROM student WHERE id = ?';
        } else if (user.role === 'professor') {
            nameQuery = 'SELECT name FROM professor WHERE id = ?';
        } else if (user.role === 'staff') {
            nameQuery = 'SELECT name FROM staff WHERE id = ?';
        }

        let name = '';
        if (nameQuery) {
            const [rows] = await db.execute(nameQuery, [user.id]);
            if (rows.length > 0) {
                name = rows[0].name;
            }
        }

        res.json({ success: true, role: user.role, username: name });
    } else {
        res.json({ success: false, message: '아이디 또는 비밀번호가 틀렸습니다.' });
    }
};

// 수정: 회원가입
const signup = async (req, res) => {
    const db = req.app.get('db');
    const { name, userId, password, role } = req.body;

    if (!name || !userId || !password || !role) {
        return res.json({ success: false, message: '이름, 아이디, 비밀번호, 역할을 모두 입력하세요.' });
    }

    try {
        // 중복 체크
        const [rows] = await db.query('SELECT * FROM user WHERE id = ?', [userId]);
        if (rows.length > 0) {
            return res.json({ success: false, message: '이미 존재하는 아이디입니다.' });
        }

        // 중복 없으면 INSERT
        const sql = 'INSERT INTO user (name, id, password, role) VALUES (?, ?, ?, ?)';
        await db.query(sql, [name, userId, password, role]);

        res.json({ success: true, message: '회원가입 성공!' });
    } catch (err) {
        console.error('회원가입 에러:', err);
        res.status(500).json({ success: false, message: 'DB 저장 실패!' });
    }
};

module.exports = { login, signup };